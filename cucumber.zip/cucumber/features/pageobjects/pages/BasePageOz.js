'use strict';

const HeaderOz = require('../components/HeaderOz');

class BasePageOz {
        constructor() {
                
                this.HeaderOz = new HeaderOz();
        };

}

module.exports =  BasePageOz;
