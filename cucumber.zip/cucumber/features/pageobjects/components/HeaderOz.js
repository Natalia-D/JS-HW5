'use strict';

class HeaderOz {
        constructor() {

        };
        get Beauty() { return "//a[contains(text(),'Косметика, парфюмерия')]" }

		

}

module.exports = HeaderOz;