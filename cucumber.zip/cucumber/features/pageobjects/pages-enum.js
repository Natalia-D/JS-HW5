/**
 * Used for library tests
 */

const HomePageOz = require('./pages/HomePageOz');
const BeautyPage = require('./pages/BeautyPage');

module.exports = {
  HomePageOz: new HomePageOz(),
  BeautyPage: new BeautyPage(),

};